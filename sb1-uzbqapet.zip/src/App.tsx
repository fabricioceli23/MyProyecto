import React, { useState, useEffect } from 'react';
import { ProjectForm } from './components/ProjectForm';
import { ProjectList } from './components/ProjectList';
import type { Project, Task } from './types';

function App() {
  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = localStorage.getItem('projects');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('projects', JSON.stringify(projects));
  }, [projects]);

  const handleAddProject = (projectData: Omit<Project, 'id' | 'tasks'>) => {
    const newProject: Project = {
      ...projectData,
      id: crypto.randomUUID(),
      tasks: [],
    };
    setProjects((prev) => [...prev, newProject]);
  };

  const handleAddTask = (projectId: string, taskTitle: string) => {
    setProjects((prev) =>
      prev.map((project) => {
        if (project.id === projectId) {
          const newTask: Task = {
            id: crypto.randomUUID(),
            title: taskTitle,
            completed: false,
            date: new Date().toISOString(),
          };
          return {
            ...project,
            tasks: [...project.tasks, newTask],
            progress: Math.round(
              (project.tasks.filter((t) => t.completed).length / (project.tasks.length + 1)) * 100
            ),
          };
        }
        return project;
      })
    );
  };

  const handleToggleTask = (projectId: string, taskId: string) => {
    setProjects((prev) =>
      prev.map((project) => {
        if (project.id === projectId) {
          const updatedTasks = project.tasks.map((task) =>
            task.id === taskId ? { ...task, completed: !task.completed } : task
          );
          return {
            ...project,
            tasks: updatedTasks,
            progress: Math.round(
              (updatedTasks.filter((t) => t.completed).length / updatedTasks.length) * 100
            ),
          };
        }
        return project;
      })
    );
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">
            Gestor de Proyectos y Objetivos
          </h1>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1">
              <ProjectForm onAddProject={handleAddProject} />
            </div>
            <div className="md:col-span-2">
              <ProjectList
                projects={projects}
                onAddTask={handleAddTask}
                onToggleTask={handleToggleTask}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;