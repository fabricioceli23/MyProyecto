export interface Project {
  id: string;
  title: string;
  description: string;
  deadline: string;
  progress: number;
  tasks: Task[];
}

export interface Task {
  id: string;
  title: string;
  completed: boolean;
  date: string;
}