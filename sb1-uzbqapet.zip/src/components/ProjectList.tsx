import React from 'react';
import { Calendar, CheckCircle } from 'lucide-react';
import type { Project } from '../types';

interface ProjectListProps {
  projects: Project[];
  onAddTask: (projectId: string, taskTitle: string) => void;
  onToggleTask: (projectId: string, taskId: string) => void;
}

export function ProjectList({ projects, onAddTask, onToggleTask }: ProjectListProps) {
  const calculateDaysLeft = (deadline: string) => {
    const today = new Date();
    const deadlineDate = new Date(deadline);
    const diffTime = deadlineDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="space-y-6">
      {projects.map((project) => (
        <div key={project.id} className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-xl font-bold text-gray-800">{project.title}</h3>
              <p className="text-gray-600 mt-1">{project.description}</p>
            </div>
            <div className="flex items-center text-sm text-gray-500">
              <Calendar className="h-4 w-4 mr-1" />
              <span>{calculateDaysLeft(project.deadline)} días restantes</span>
            </div>
          </div>

          <div className="mt-4">
            <div className="relative pt-1">
              <div className="flex mb-2 items-center justify-between">
                <div>
                  <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200">
                    Progreso
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs font-semibold inline-block text-blue-600">
                    {project.progress}%
                  </span>
                </div>
              </div>
              <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200">
                <div
                  style={{ width: `${project.progress}%` }}
                  className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500"
                ></div>
              </div>
            </div>
          </div>

          <div className="mt-4">
            <h4 className="font-semibold text-gray-700 mb-2">Tareas</h4>
            <ul className="space-y-2">
              {project.tasks.map((task) => (
                <li
                  key={task.id}
                  className="flex items-center space-x-2 text-gray-700 cursor-pointer"
                  onClick={() => onToggleTask(project.id, task.id)}
                >
                  <CheckCircle
                    className={`h-5 w-5 ${
                      task.completed ? 'text-green-500' : 'text-gray-400'
                    }`}
                  />
                  <span className={task.completed ? 'line-through text-gray-400' : ''}>
                    {task.title}
                  </span>
                </li>
              ))}
            </ul>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const input = e.currentTarget.elements.namedItem('task') as HTMLInputElement;
                if (input.value.trim()) {
                  onAddTask(project.id, input.value.trim());
                  input.value = '';
                }
              }}
              className="mt-3"
            >
              <input
                type="text"
                name="task"
                placeholder="Agregar nueva tarea..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </form>
          </div>
        </div>
      ))}
    </div>
  );
}