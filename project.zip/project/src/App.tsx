import React, { useState } from 'react';
import { Book, Code, Database, Globe, Server, Shield, Laptop, Search, BookOpen, Youtube, Globe2, GraduationCap } from 'lucide-react';

interface Resource {
  title: string;
  description: string;
  url: string;
  icon: React.ReactNode;
}

interface Topic {
  id: number;
  title: string;
  description: string;
  icon: React.ReactNode;
  keyPoints: string[];
  resources: Resource[];
}

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedTopic, setExpandedTopic] = useState<number | null>(null);
  
  const topics: Topic[] = [
    {
      id: 1,
      title: 'Programación',
      description: 'Comienza tu viaje en la programación con lenguajes amigables para principiantes como Python y JavaScript.',
      icon: <Code className="w-8 h-8 text-blue-500" />,
      keyPoints: [
        'Conceptos básicos de programación y lógica',
        'Variables, tipos de datos y estructuras de control',
        'Funciones y módulos básicos',
        'Introducción a la programación orientada a objetos',
        'Primeros pasos con Git y GitHub'
      ],
      resources: [
        {
          title: 'freeCodeCamp en Español',
          description: 'Curso gratuito de JavaScript y desarrollo web',
          url: 'https://www.freecodecamp.org/espanol/',
          icon: <BookOpen className="w-6 h-6 text-blue-500" />
        },
        {
          title: 'Píldoras Informáticas',
          description: 'Canal con tutoriales básicos de programación',
          url: 'https://www.youtube.com/@pildorasinformaticas',
          icon: <Youtube className="w-6 h-6 text-red-500" />
        },
        {
          title: 'SoloLearn',
          description: 'App para aprender programación desde cero',
          url: 'https://www.sololearn.com/',
          icon: <GraduationCap className="w-6 h-6 text-green-500" />
        }
      ]
    },
    {
      id: 2,
      title: 'Bases de Datos',
      description: 'Aprende los fundamentos de las bases de datos relacionales con MySQL y PostgreSQL.',
      icon: <Database className="w-8 h-8 text-green-500" />,
      keyPoints: [
        'Conceptos básicos de bases de datos',
        'Consultas SQL básicas (SELECT, INSERT, UPDATE, DELETE)',
        'Diseño simple de bases de datos',
        'Relaciones entre tablas',
        'Primeros pasos con MySQL'
      ],
      resources: [
        {
          title: 'W3Schools SQL Tutorial',
          description: 'Tutorial interactivo de SQL para principiantes',
          url: 'https://www.w3schools.com/sql/',
          icon: <BookOpen className="w-6 h-6 text-blue-500" />
        },
        {
          title: 'HolaMundo',
          description: 'Tutoriales de bases de datos para principiantes',
          url: 'https://www.youtube.com/@HolaMundo',
          icon: <Youtube className="w-6 h-6 text-red-500" />
        },
        {
          title: 'SQLBolt',
          description: 'Lecciones interactivas de SQL',
          url: 'https://sqlbolt.com/',
          icon: <GraduationCap className="w-6 h-6 text-green-500" />
        }
      ]
    },
    {
      id: 3,
      title: 'Redes',
      description: 'Descubre los conceptos básicos de redes y comunicación entre computadoras.',
      icon: <Globe className="w-8 h-8 text-purple-500" />,
      keyPoints: [
        'Conceptos básicos de redes',
        'Direcciones IP y máscaras de red',
        'Configuración básica de routers',
        'Protocolos comunes (HTTP, FTP, DNS)',
        'Seguridad básica en redes'
      ],
      resources: [
        {
          title: 'Curso de Redes de Cisco',
          description: 'Fundamentos de Networking',
          url: 'https://www.netacad.com/courses/networking',
          icon: <BookOpen className="w-6 h-6 text-blue-500" />
        },
        {
          title: 'Redes desde Cero',
          description: 'Canal de YouTube sobre redes',
          url: 'https://www.youtube.com/@RedesesdeCero',
          icon: <Laptop className="w-6 h-6 text-indigo-500" />
        },
        {
          title: 'NetworkChuck',
          description: 'Tutoriales amigables de redes',
          url: 'https://www.youtube.com/@NetworkChuck',
          icon: <Globe2 className="w-6 h-6 text-purple-500" />
        }
      ]
    },
    {
      id: 4,
      title: 'Sistemas Operativos',
      description: 'Aprende lo básico sobre Windows, Linux y la administración de sistemas.',
      icon: <Server className="w-8 h-8 text-orange-500" />,
      keyPoints: [
        'Fundamentos de sistemas operativos',
        'Comandos básicos de Linux',
        'Gestión de archivos y permisos',
        'Instalación de programas',
        'Introducción a la virtualización'
      ],
      resources: [
        {
          title: 'Linux Journey',
          description: 'Aprende Linux paso a paso',
          url: 'https://linuxjourney.com/',
          icon: <BookOpen className="w-6 h-6 text-blue-500" />
        },
        {
          title: 'Pelado Nerd',
          description: 'Tutoriales de Linux y sistemas',
          url: 'https://www.youtube.com/@PeladoNerd',
          icon: <Laptop className="w-6 h-6 text-indigo-500" />
        },
        {
          title: 'Linux Foundation',
          description: 'Cursos gratuitos de Linux',
          url: 'https://training.linuxfoundation.org/free-courses/',
          icon: <Globe2 className="w-6 h-6 text-purple-500" />
        }
      ]
    },
    {
      id: 5,
      title: 'Ciberseguridad',
      description: 'Introducción a la seguridad informática y protección de datos.',
      icon: <Shield className="w-8 h-8 text-red-500" />,
      keyPoints: [
        'Conceptos básicos de seguridad',
        'Contraseñas seguras y autenticación',
        'Protección contra malware',
        'Seguridad en redes WiFi',
        'Navegación segura en internet'
      ],
      resources: [
        {
          title: 'Cybrary',
          description: 'Cursos gratuitos de ciberseguridad',
          url: 'https://www.cybrary.it/',
          icon: <Laptop className="w-6 h-6 text-indigo-500" />
        },
        {
          title: 'S4vitar',
          description: 'Canal de hacking ético en español',
          url: 'https://www.youtube.com/@s4vitar',
          icon: <BookOpen className="w-6 h-6 text-blue-500" />
        },
        {
          title: 'PortSwigger Academy',
          description: 'Aprende seguridad web',
          url: 'https://portswigger.net/web-security',
          icon: <Globe2 className="w-6 h-6 text-purple-500" />
        }
      ]
    },
    {
      id: 6,
      title: 'Desarrollo Web',
      description: 'Comienza en el desarrollo web con HTML, CSS y JavaScript básico.',
      icon: <Laptop className="w-8 h-8 text-indigo-500" />,
      keyPoints: [
        'HTML5 y estructura web básica',
        'CSS y estilos fundamentales',
        'JavaScript para principiantes',
        'Responsive design básico',
        'Herramientas de desarrollo web'
      ],
      resources: [
        {
          title: 'MDN Web Docs',
          description: 'Guías de desarrollo web',
          url: 'https://developer.mozilla.org/es/',
          icon: <BookOpen className="w-6 h-6 text-blue-500" />
        },
        {
          title: 'Fazt',
          description: 'Tutoriales de desarrollo web',
          url: 'https://www.youtube.com/@FaztTech',
          icon: <Youtube className="w-6 h-6 text-red-500" />
        },
        {
          title: 'Frontend Mentor',
          description: 'Proyectos prácticos para principiantes',
          url: 'https://www.frontendmentor.io/',
          icon: <GraduationCap className="w-6 h-6 text-green-500" />
        }
      ]
    }
  ];

  const filteredTopics = topics.filter(topic =>
    topic.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    topic.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div 
        className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-20"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80")',
          backgroundBlend: 'overlay',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <Book className="w-16 h-16 mx-auto mb-6" />
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Comienza tu Viaje en TI
            </h1>
            <p className="text-xl mb-8">
              Guía práctica para principiantes y estudiantes intermedios en Tecnologías de la Información
            </p>
            <div className="relative max-w-xl mx-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar temas..."
                className="w-full pl-12 pr-4 py-3 rounded-full text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Topics Grid */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredTopics.map((topic) => (
            <div
              key={topic.id}
              className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300"
            >
              <div className="p-6">
                <div className="flex items-center mb-4">
                  {topic.icon}
                  <h3 className="text-xl font-semibold ml-3">{topic.title}</h3>
                </div>
                <p className="text-gray-600 mb-4">{topic.description}</p>
                <button 
                  className="text-blue-600 hover:text-blue-800 font-medium flex items-center"
                  onClick={() => setExpandedTopic(expandedTopic === topic.id ? null : topic.id)}
                >
                  {expandedTopic === topic.id ? 'Ver menos' : 'Ver más'}
                  <svg 
                    className={`w-4 h-4 ml-2 transform transition-transform ${expandedTopic === topic.id ? 'rotate-90' : ''}`} 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
              
              {expandedTopic === topic.id && (
                <div className="px-6 pb-6">
                  <div className="border-t pt-4">
                    <h4 className="font-semibold text-lg mb-3">Lo que Aprenderás:</h4>
                    <ul className="list-disc list-inside space-y-2 text-gray-600 mb-6">
                      {topic.keyPoints.map((point, index) => (
                        <li key={index}>{point}</li>
                      ))}
                    </ul>
                    
                    <h4 className="font-semibold text-lg mb-3">Recursos Recomendados:</h4>
                    <div className="space-y-4">
                      {topic.resources.map((resource, index) => (
                        <a
                          key={index}
                          href={resource.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-start p-3 rounded-lg hover:bg-gray-50 transition-colors duration-200"
                        >
                          <div className="mt-1">{resource.icon}</div>
                          <div className="ml-3">
                            <h5 className="font-medium text-blue-600">{resource.title}</h5>
                            <p className="text-gray-600 text-sm">{resource.description}</p>
                          </div>
                        </a>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-400">
            © {new Date().getFullYear()} Plataforma de Aprendizaje TI. Todos los derechos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;